# RAW Drive Fixer (Android, USB OTG)

Plug a USB flash drive or SD card reader into your phone with an OTG adapter. If it shows as **RAW / unsupported / needs formatting**, this app can:

1. **Diagnose** – reads the start of the drive and tells you why it's RAW (damaged boot sector, wiped partition table, ...).
2. **Recover files** (read-only, safe) – scans the whole drive for JPG, PNG, HEIC, MP4/MOV/3GP, PDF and ZIP/DOCX/XLSX/PPTX/APK files and copies them to `Downloads/RawRecover/<date>/`.
3. **Repair** (writes to the drive) – restores the backup boot sector (FAT32, exFAT, NTFS) or rebuilds a wiped MBR partition table. The original sectors are saved to `Downloads/RawRecover/backup_*` first and every write is verified.

No root needed. It talks to the drive over the USB Mass Storage protocol, so it works even when the file system is unreadable.

## Get the APK (no Android Studio needed)

1. Create a new **empty GitHub repository**.
2. Upload / push everything in this folder to it (keep the `.github` folder).
3. Open the repo's **Actions** tab -> **Build APK** -> wait ~3-5 minutes.
4. Open the finished run -> **Artifacts** -> download **RawDriveFixer-apk** -> unzip -> install `app-debug.apk` on your phone (allow "install unknown apps").

Or build locally: open the folder in Android Studio and run **Build > Build APK(s)**.

## Limits (be aware)

- Needs Android 10+ and a phone with USB OTG.
- Works with normal USB flash drives and card readers (USB "Bulk-Only"). UAS-only drives, some NVMe/SSD enclosures and 4Kn drives are not supported for diagnose/repair.
- Recovery works by file signature: **original file names and folders are lost**, and fragmented files may come out incomplete or corrupt. Camera RAW photo formats (CR2, NEF, ARW...) are not carved yet.
- Repair only fixes boot-sector / partition-table damage. If the file system itself is corrupted, use **Recover files** and then format the drive.
- Always run **Recover files before Repair** if the data matters.
- Only the first 2 TB of a drive is addressable.
- Android may not mount NTFS volumes even after repair - recovered files in Downloads are the reliable result.
