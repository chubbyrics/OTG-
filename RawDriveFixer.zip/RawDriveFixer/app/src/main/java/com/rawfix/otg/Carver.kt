package com.rawfix.otg

import android.content.Context
import android.webkit.MimeTypeMap
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Random access over the raw drive with a 1 MB read window. */
class Cache(private val d: UsbDrive) {
    private val bs = d.blockSize
    private val winBytes = max(1, (1 shl 20) / bs) * bs
    private var winStart = -1L
    private var win = ByteArray(0)
    val size = d.sizeBytes

    fun at(pos: Long): Int {
        if (pos < 0 || pos >= size) return -1
        if (pos < winStart || pos >= winStart + win.size) {
            winStart = pos / winBytes * winBytes
            val lba = winStart / bs
            val cnt = min((winBytes / bs).toLong(), d.blockCount - lba).toInt()
            win = d.readLenient(lba, cnt)
        }
        val i = (pos - winStart).toInt()
        return if (i >= 0 && i < win.size) win[i].toInt() and 0xFF else -1
    }

    fun be32(p: Long): Long {
        var v = 0L
        for (k in 0..3) {
            val b = at(p + k)
            if (b < 0) return -1
            v = (v shl 8) or b.toLong()
        }
        return v
    }

    fun tag(p: Long): String {
        val sb = StringBuilder()
        for (k in 0..3) {
            val b = at(p + k)
            if (b < 0) return ""
            sb.append(b.toChar())
        }
        return sb.toString()
    }

    fun bytes(p: Long, n: Int): ByteArray {
        val out = ByteArray(n)
        for (i in 0 until n) {
            val b = at(p + i)
            out[i] = if (b < 0) 0 else b.toByte()
        }
        return out
    }

    /** Streams [start, end) of the drive into [os]. */
    fun copy(start: Long, end: Long, os: OutputStream) {
        var pos = start
        val maxBlocks = max(1, (1 shl 20) / bs)
        while (pos < end) {
            val lba = pos / bs
            val need = ((end - lba * bs) + bs - 1) / bs
            val blocks = min(need, maxBlocks.toLong()).toInt()
            val buf = d.readLenient(lba, blocks)
            val from = (pos - lba * bs).toInt()
            val to = min(buf.size.toLong(), end - lba * bs).toInt()
            os.write(buf, from, to - from)
            pos = lba * bs + to
        }
    }
}

enum class Kind(val minSize: Long, val cap: Long) {
    JPEG(4096, 64L shl 20),
    PNG(1024, 64L shl 20),
    MP4(20000, 4L shl 30),
    ZIP(100, 512L shl 20),
    PDF(1024, 128L shl 20)
}

/**
 * Signature-based file recovery ("carving"). It ignores the broken file system completely and
 * looks for the start of known file types, works out where each file ends, and copies it
 * to Downloads/RawRecover. File names and folders are NOT recoverable this way, and files that
 * were fragmented on the drive may come out incomplete.
 */
class Carver(
    private val ctx: Context,
    private val d: UsbDrive,
    private val ctl: Ctl,
    val folder: String,
    private val startLba: Long,
    serialStart: Int,
    private val checkpoint: (Long, Int) -> Unit = { _, _ -> }
) {
    companion object {
        fun newFolderName(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    }

    private val bs = d.blockSize
    private val cache = Cache(d)
    private val counts = HashMap<String, Int>()
    var serial = serialStart
        private set
    private var fatal = false

    /** Where a later run should continue (sector number). */
    var resumeLba = startLba
        private set
    var completed = false
        private set

    private val mp4Boxes = setOf(
        "ftyp", "moov", "mdat", "free", "skip", "wide", "uuid", "moof", "mfra",
        "meta", "styp", "sidx", "pdin", "pnot", "junk"
    )

    fun run() {
        val total = d.blockCount
        val chunk = max(1, (1 shl 20) / bs)
        var lba = startLba
        if (lba < 0 || lba >= total) lba = 0L
        var skipUntil = lba
        var lastPct = -1
        resumeLba = lba
        ctl.log("Scanning ${fmtSize(d.sizeBytes)} for photos, videos, PDFs and zip/Office files...")
        if (lba > 0) ctl.log("Starting at ${pctText(lba, total)}% of the drive.")
        ctl.log("Files are saved to Downloads/RawRecover/$folder")
        while (lba < total && !ctl.stopped() && !fatal) {
            val cnt = min(chunk.toLong(), total - lba).toInt()
            val buf = d.readLenient(lba, cnt)
            var aborted = false
            for (i in 0 until cnt) {
                if (fatal || ctl.stopped()) {
                    aborted = true
                    break
                }
                val cur = lba + i
                if (cur < skipUntil) continue
                val kind = signature(buf, i * bs) ?: continue
                val start = cur * bs
                var end = endOf(kind, start)
                if (end > d.sizeBytes) end = d.sizeBytes
                if (end > start && end - start >= kind.minSize) {
                    if (save(kind, start, end)) skipUntil = (end + bs - 1) / bs
                }
            }
            if (aborted) {
                resumeLba = max(lba, skipUntil)
                break
            }
            lba += cnt
            resumeLba = max(lba, skipUntil)
            val pct = (lba * 100 / total).toInt()
            if (pct != lastPct) {
                lastPct = pct
                ctl.progress(pct)
                checkpoint(resumeLba, serial)
            }
            if (d.badReads > 400) {
                ctl.log("Too many unreadable areas - the drive is probably failing or was unplugged. Stopping.")
                break
            }
        }
        completed = resumeLba >= total && !fatal
        val sum = counts.entries.sortedBy { it.key }.joinToString(", ") { "${it.value} x ${it.key}" }
        if (completed) {
            ctl.log(
                if (counts.isEmpty()) "Finished. No recoverable files were found."
                else "Finished. Recovered: $sum. Open the Files app > Downloads > RawRecover."
            )
        } else {
            ctl.log("Stopped at ${pctText(resumeLba, total)}%. " + (if (counts.isEmpty()) "" else "Recovered so far: $sum. "))
            ctl.log("Tap 'Resume where it stopped' to continue from here, or type a % in the Start at box.")
        }
        if (d.badReads > 0) ctl.log("${d.badReads} unreadable area(s) were skipped (filled with zeros).")
    }

    private fun pctText(lba: Long, total: Long): String =
        String.format(Locale.US, "%.2f", lba * 100.0 / total)

    private fun signature(b: ByteArray, o: Int): Kind? {
        val b0 = B.u8(b, o)
        val b1 = B.u8(b, o + 1)
        val b2 = B.u8(b, o + 2)
        val b3 = B.u8(b, o + 3)
        if (b0 == 0xFF && b1 == 0xD8 && b2 == 0xFF) return Kind.JPEG
        if (b0 == 0x89 && b1 == 0x50 && b2 == 0x4E && b3 == 0x47 &&
            B.u8(b, o + 4) == 0x0D && B.u8(b, o + 5) == 0x0A && B.u8(b, o + 6) == 0x1A && B.u8(b, o + 7) == 0x0A
        ) return Kind.PNG
        if (b0 == 0x25 && b1 == 0x50 && b2 == 0x44 && b3 == 0x46 && B.u8(b, o + 4) == 0x2D) return Kind.PDF
        if (b0 == 0x50 && b1 == 0x4B && b2 == 0x03 && b3 == 0x04) return Kind.ZIP
        if (B.ascii(b, o + 4, 4) == "ftyp") {
            val sz = B.be32(b, o)
            if (sz in 12L..256L) return Kind.MP4
        }
        return null
    }

    private fun looksLikeHeader(p: Long): Boolean {
        val h = cache.bytes(p, 12)
        return signature(h + ByteArray(512), 0) != null
    }

    private fun endOf(kind: Kind, s: Long): Long = when (kind) {
        Kind.JPEG -> jpegEnd(s, kind.cap)
        Kind.PNG -> pngEnd(s, kind.cap)
        Kind.MP4 -> mp4End(s, kind.cap)
        Kind.ZIP -> zipEnd(s, kind.cap)
        Kind.PDF -> pdfEnd(s, kind.cap)
    }

    /** Walks the JPEG segment structure so embedded thumbnails don't end the file early. */
    private fun jpegEnd(s: Long, cap: Long): Long {
        var p = s + 2
        val limit = s + cap
        while (p < limit) {
            if (cache.at(p) != 0xFF) return -1
            var m = cache.at(p + 1)
            while (m == 0xFF) {
                p++
                m = cache.at(p + 1)
            }
            if (m < 0) return -1
            if (m == 0xD9) return p + 2
            if (m == 0xD8 || m == 0x01 || (m in 0xD0..0xD7)) {
                p += 2
                continue
            }
            if (m == 0x00) return -1
            val l1 = cache.at(p + 2)
            val l2 = cache.at(p + 3)
            if (l1 < 0 || l2 < 0) return -1
            val len = (l1 shl 8) or l2
            if (len < 2) return -1
            p += 2 + len
            if (m == 0xDA) {
                // entropy-coded image data: runs until a real marker
                while (p < limit) {
                    val b = cache.at(p)
                    if (b < 0) return -1
                    if (b == 0xFF) {
                        val n = cache.at(p + 1)
                        if (n < 0) return -1
                        if (n == 0x00 || (n in 0xD0..0xD7)) {
                            p += 2
                            continue
                        }
                        if (n == 0xFF) {
                            p += 1
                            continue
                        }
                        break
                    } else {
                        p++
                    }
                }
            }
        }
        return -1
    }

    private fun pngEnd(s: Long, cap: Long): Long {
        var p = s + 8
        while (p - s < cap) {
            val len = cache.be32(p)
            if (len < 0 || len > cap) return -1
            val type = cache.tag(p + 4)
            if (type.length != 4 || !type.all { it in 'A'..'z' }) return -1
            p += 12 + len
            if (type == "IEND") return p
        }
        return -1
    }

    /** MP4/MOV/HEIC are a chain of boxes, each starting with its own size - so the exact end is known. */
    private fun mp4End(s: Long, cap: Long): Long {
        var p = s
        var boxes = 0
        var sawFtyp = false
        while (p - s < cap) {
            var sz = cache.be32(p)
            val type = cache.tag(p + 4)
            if (sz < 0 || type.isEmpty() || !mp4Boxes.contains(type)) break
            var hdr = 8L
            if (sz == 1L) {
                val hi = cache.be32(p + 8)
                val lo = cache.be32(p + 12)
                if (hi < 0 || lo < 0) break
                sz = (hi shl 32) or lo
                hdr = 16L
            }
            if (sz < hdr) break
            if (type == "ftyp") {
                if (boxes != 0) break
                sawFtyp = true
            }
            p += sz
            boxes++
        }
        return if (sawFtyp && boxes >= 2) p else -1
    }

    private fun zipEnd(s: Long, cap: Long): Long {
        var p = s + 4
        val lim = s + cap
        while (p < lim) {
            val b = cache.at(p)
            if (b < 0) return -1
            if (b == 0x50 && cache.at(p + 1) == 0x4B && cache.at(p + 2) == 5 && cache.at(p + 3) == 6) {
                val c0 = cache.at(p + 20)
                val c1 = cache.at(p + 21)
                if (c0 < 0 || c1 < 0) return -1
                return p + 22 + (c0 or (c1 shl 8))
            }
            p++
        }
        return -1
    }

    private fun pdfEnd(s: Long, cap: Long): Long {
        var p = s + 5
        var lastEof = -1L
        val lim = min(s + cap, d.sizeBytes)
        while (p < lim) {
            if (p % bs == 0L) {
                if (looksLikeHeader(p)) break
                if (lastEof > 0 && cache.bytes(p, 16).all { it.toInt() == 0 }) break
            }
            if (cache.at(p) == '%'.code && cache.at(p + 1) == '%'.code && cache.at(p + 2) == 'E'.code &&
                cache.at(p + 3) == 'O'.code && cache.at(p + 4) == 'F'.code
            ) {
                lastEof = p + 5
                p += 5
                continue
            }
            p++
        }
        if (lastEof < 0) return -1
        var e = lastEof
        var k = 0
        while (k < 2) {
            val b = cache.at(e)
            if (b == 10 || b == 13) {
                e++
                k++
            } else break
        }
        return e
    }

    private fun extFor(kind: Kind, start: Long): String = when (kind) {
        Kind.JPEG -> "jpg"
        Kind.PNG -> "png"
        Kind.PDF -> "pdf"
        Kind.MP4 -> {
            val brand = cache.tag(start + 8)
            when {
                brand == "qt  " -> "mov"
                brand.startsWith("hei") || brand == "mif1" || brand == "msf1" -> "heic"
                brand == "avif" -> "avif"
                brand == "M4A " -> "m4a"
                brand.startsWith("3g") -> "3gp"
                else -> "mp4"
            }
        }
        Kind.ZIP -> {
            val head = String(cache.bytes(start, 16384), Charsets.ISO_8859_1)
            when {
                head.contains("word/") -> "docx"
                head.contains("xl/") -> "xlsx"
                head.contains("ppt/") -> "pptx"
                head.contains("AndroidManifest.xml") -> "apk"
                else -> "zip"
            }
        }
    }

    private fun save(kind: Kind, start: Long, end: Long): Boolean {
        val ext = extFor(kind, start)
        serial++
        val name = String.format(Locale.US, "recovered_%05d.%s", serial, ext)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val out = Saver.open(ctx, folder, name, mime)
        if (out == null) {
            ctl.log("Cannot create files in Downloads (is the phone storage full?). Stopping.")
            fatal = true
            return false
        }
        var ok = false
        try {
            cache.copy(start, end, out.second)
            ok = true
        } catch (e: IOException) {
            ctl.log("Write error: ${e.message}. Is the phone storage full?")
            fatal = true
        } finally {
            try {
                out.second.close()
            } catch (_: Exception) {
            }
        }
        if (!ok) {
            Saver.discard(ctx, out.first)
            return false
        }
        Saver.finish(ctx, out.first)
        counts[ext] = (counts[ext] ?: 0) + 1
        ctl.log("OK $name  ${fmtSize(end - start)}")
        return true
    }
}
