package com.rawfix.otg

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import kotlin.math.max
import kotlin.math.min

/**
 * Talks to a USB flash drive / card reader directly using the USB Mass Storage
 * "Bulk-Only Transport" protocol and raw SCSI commands. No root needed, and it does
 * not care whether the file system is damaged or "RAW" - it reads sectors.
 */
class UsbDrive(
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val bulkIn: UsbEndpoint,
    private val bulkOut: UsbEndpoint
) {
    var blockSize = 512
    var blockCount = 0L
    var label = ""
    @Volatile
    var badReads = 0
    val sizeBytes: Long get() = blockCount * blockSize

    private var tag = 0x1000

    companion object {
        const val TIMEOUT = 8000
        const val CHUNK = 16384
        const val MAXXFER = 65536
    }

    private fun put32le(b: ByteArray, o: Int, v: Int) {
        b[o] = v.toByte()
        b[o + 1] = (v shr 8).toByte()
        b[o + 2] = (v shr 16).toByte()
        b[o + 3] = (v shr 24).toByte()
    }

    private fun clearHalt(ep: UsbEndpoint) {
        conn.controlTransfer(0x02, 0x01, 0, ep.address, null, 0, TIMEOUT)
    }

    private fun resetBot() {
        conn.controlTransfer(0x21, 0xFF, 0, iface.id, null, 0, TIMEOUT)
        clearHalt(bulkIn)
        clearHalt(bulkOut)
    }

    @Synchronized
    private fun scsi(cdb: ByteArray, dataLen: Int, dataIn: Boolean, buf: ByteArray?, bufOff: Int = 0): Boolean {
        val cbw = ByteArray(31)
        cbw[0] = 0x55
        cbw[1] = 0x53
        cbw[2] = 0x42
        cbw[3] = 0x43
        tag++
        put32le(cbw, 4, tag)
        put32le(cbw, 8, dataLen)
        cbw[12] = if (dataLen > 0 && dataIn) 0x80.toByte() else 0
        cbw[13] = 0
        cbw[14] = cdb.size.toByte()
        System.arraycopy(cdb, 0, cbw, 15, cdb.size)
        if (conn.bulkTransfer(bulkOut, cbw, 31, TIMEOUT) != 31) {
            resetBot()
            return false
        }
        var ok = true
        if (dataLen > 0 && buf != null) {
            var done = 0
            while (done < dataLen) {
                val n = min(CHUNK, dataLen - done)
                val r = if (dataIn) conn.bulkTransfer(bulkIn, buf, bufOff + done, n, TIMEOUT)
                else conn.bulkTransfer(bulkOut, buf, bufOff + done, n, TIMEOUT)
                if (r <= 0) {
                    ok = false
                    break
                }
                done += r
            }
        }
        val csw = ByteArray(13)
        var r = conn.bulkTransfer(bulkIn, csw, 13, TIMEOUT)
        if (r < 0) {
            clearHalt(bulkIn)
            r = conn.bulkTransfer(bulkIn, csw, 13, TIMEOUT)
        }
        if (r != 13) {
            resetBot()
            return false
        }
        val sigOk = csw[0] == 0x55.toByte() && csw[1] == 0x53.toByte() &&
            csw[2] == 0x42.toByte() && csw[3] == 0x53.toByte()
        if (!sigOk) {
            resetBot()
            return false
        }
        return ok && csw[12].toInt() == 0
    }

    private fun testReady(): Boolean = scsi(ByteArray(6), 0, true, null)

    private fun requestSense() {
        val b = ByteArray(18)
        scsi(byteArrayOf(0x03, 0, 0, 0, 18, 0), 18, true, b)
    }

    fun init(): Boolean {
        var ready = false
        for (i in 0 until 8) {
            if (testReady()) {
                ready = true
                break
            }
            requestSense()
            Thread.sleep(400)
        }
        if (!ready) return false
        val inq = ByteArray(36)
        if (scsi(byteArrayOf(0x12, 0, 0, 0, 36, 0), 36, true, inq)) {
            label = (B.ascii(inq, 8, 8).trim() + " " + B.ascii(inq, 16, 16).trim()).trim()
        }
        val cap = ByteArray(8)
        if (!scsi(ByteArray(10).also { it[0] = 0x25 }, 8, true, cap)) return false
        val last = B.be32(cap, 0)
        blockSize = B.be32(cap, 4).toInt()
        blockCount = last + 1
        return blockSize in 512..65536 && blockCount > 0
    }

    private fun rwCdb(op: Int, lba: Long, n: Int): ByteArray = byteArrayOf(
        op.toByte(), 0,
        (lba shr 24).toByte(), (lba shr 16).toByte(), (lba shr 8).toByte(), lba.toByte(),
        0, (n shr 8).toByte(), n.toByte(), 0
    )

    /** Strict read: returns null if any part fails. */
    fun read(lba: Long, count: Int): ByteArray? {
        if (lba < 0 || count <= 0 || lba + count > blockCount) return null
        val out = ByteArray(count * blockSize)
        val per = max(1, MAXXFER / blockSize)
        var done = 0
        while (done < count) {
            val n = min(per, count - done)
            var ok = scsi(rwCdb(0x28, lba + done, n), n * blockSize, true, out, done * blockSize)
            if (!ok) {
                requestSense()
                ok = scsi(rwCdb(0x28, lba + done, n), n * blockSize, true, out, done * blockSize)
            }
            if (!ok) return null
            done += n
        }
        return out
    }

    /** Reads as much as possible; unreadable pieces come back as zeros and are counted in badReads. */
    fun readLenient(lba: Long, count: Int): ByteArray {
        val whole = read(lba, count)
        if (whole != null) return whole
        val out = ByteArray(count * blockSize)
        val per = max(1, MAXXFER / blockSize)
        var done = 0
        while (done < count) {
            val n = min(per, count - done)
            val r = read(lba + done, n)
            if (r != null) System.arraycopy(r, 0, out, done * blockSize, r.size) else badReads++
            done += n
        }
        return out
    }

    fun write(lba: Long, data: ByteArray): Boolean {
        if (data.size % blockSize != 0) return false
        val count = data.size / blockSize
        if (lba < 0 || lba + count > blockCount) return false
        val per = max(1, MAXXFER / blockSize)
        var done = 0
        while (done < count) {
            val n = min(per, count - done)
            var ok = scsi(rwCdb(0x2A, lba + done, n), n * blockSize, false, data, done * blockSize)
            if (!ok) {
                requestSense()
                ok = scsi(rwCdb(0x2A, lba + done, n), n * blockSize, false, data, done * blockSize)
            }
            if (!ok) return false
            done += n
        }
        return true
    }

    fun close() {
        try {
            conn.releaseInterface(iface)
            conn.close()
        } catch (_: Exception) {
        }
    }
}
