package com.rawfix.otg

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        const val ACTION_PERM = "com.rawfix.otg.USB_PERMISSION"
    }

    private lateinit var usb: UsbManager
    private lateinit var statusTv: TextView
    private lateinit var logTv: TextView
    private lateinit var scroll: ScrollView
    private lateinit var bar: ProgressBar
    private lateinit var startPct: EditText

    private var drive: UsbDrive? = null
    private val exec = Executors.newSingleThreadExecutor()

    @Volatile
    private var busy = false

    @Volatile
    private var stopFlag = false

    private val ctl = Ctl(
        log = { msg -> log(msg) },
        progress = { pct -> runOnUiThread { bar.progress = pct } },
        stopped = { stopFlag }
    )

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERM -> {
                    val dev = deviceExtra(i)
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) {
                        openDrive(dev)
                    } else {
                        log("USB permission was denied. Tap Connect and choose Allow.")
                    }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    stopFlag = true
                    drive?.close()
                    drive = null
                    setStatus("No drive connected")
                    log("Drive was unplugged.")
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun deviceExtra(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()

        val f = IntentFilter(ACTION_PERM)
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(usbReceiver, f)

        log("Plug your drive in through the OTG adapter, then tap Connect.")
        log("Tip: if the drive is important, use 'Recover files' BEFORE 'Repair'.")
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopFlag = true
        try {
            unregisterReceiver(usbReceiver)
        } catch (_: Exception) {
        }
        drive?.close()
        exec.shutdown()
    }

    // ---------- UI ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(16))

        val title = TextView(this)
        title.text = "RAW Drive Fixer"
        title.textSize = 24f
        title.setTypeface(null, Typeface.BOLD)
        root.addView(title)

        statusTv = TextView(this)
        statusTv.text = "No drive connected"
        statusTv.textSize = 15f
        statusTv.setPadding(0, dp(4), 0, dp(8))
        root.addView(statusTv)

        root.addView(button("1. Connect USB drive") { connect() })
        root.addView(button("2. Diagnose") { diagnose() })
        startPct = EditText(this)
        startPct.hint = "Start at % of the drive (optional, e.g. 40)"
        startPct.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        root.addView(startPct)
        root.addView(button("3. Recover files (safe, read-only)") { recover(false) })
        root.addView(button("Resume where it stopped") { recover(true) })
        root.addView(button("4. Repair (writes to the drive)") { repair() })
        root.addView(button("Stop") {
            stopFlag = true
            log("Stopping...")
        })

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        root.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        scroll = ScrollView(this)
        logTv = TextView(this)
        logTv.typeface = Typeface.MONOSPACE
        logTv.textSize = 12f
        logTv.setTextIsSelectable(true)
        scroll.addView(logTv)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun log(msg: String) {
        runOnUiThread {
            logTv.append(msg + "\n")
            if (logTv.length() > 30000) logTv.text = logTv.text.takeLast(20000)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setStatus(s: String) {
        runOnUiThread { statusTv.text = s }
    }

    private fun runTask(block: () -> Unit) {
        if (busy) {
            log("Another task is still running. Tap Stop first.")
            return
        }
        busy = true
        stopFlag = false
        exec.execute {
            try {
                block()
            } catch (t: Throwable) {
                log("Error: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                busy = false
                runOnUiThread { bar.progress = 0 }
            }
        }
    }

    // ---------- USB ----------

    private fun isStorage(dev: UsbDevice): Boolean {
        for (i in 0 until dev.interfaceCount) {
            if (dev.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE) return true
        }
        return false
    }

    private fun connect() {
        val dev = usb.deviceList.values.firstOrNull { isStorage(it) }
        if (dev == null) {
            log("No USB storage device found. Check the OTG adapter and cable, then tap Connect again.")
            return
        }
        if (usb.hasPermission(dev)) {
            openDrive(dev)
        } else {
            log("Android is asking for USB access - tap OK / Allow.")
            val intent = Intent(ACTION_PERM).setPackage(packageName)
            val pi = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_MUTABLE)
            usb.requestPermission(dev, pi)
        }
    }

    private class Bot(val iface: UsbInterface, val bulkIn: UsbEndpoint, val bulkOut: UsbEndpoint)

    private fun findBot(dev: UsbDevice): Bot? {
        for (i in 0 until dev.interfaceCount) {
            val f = dev.getInterface(i)
            if (f.interfaceClass != UsbConstants.USB_CLASS_MASS_STORAGE) continue
            if (f.interfaceSubclass != 6 || f.interfaceProtocol != 0x50) continue
            var epIn: UsbEndpoint? = null
            var epOut: UsbEndpoint? = null
            for (e in 0 until f.endpointCount) {
                val ep = f.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) epIn = ep else epOut = ep
                }
            }
            if (epIn != null && epOut != null) return Bot(f, epIn, epOut)
        }
        return null
    }

    private fun openDrive(dev: UsbDevice) {
        runTask {
            log("Opening the drive...")
            val bot = findBot(dev)
            if (bot == null) {
                log("This drive uses a USB mode (UAS or non-standard) that this app can't talk to.")
                return@runTask
            }
            val conn = usb.openDevice(dev)
            if (conn == null) {
                log("Could not open the USB device.")
                return@runTask
            }
            if (!conn.claimInterface(bot.iface, true)) {
                log("Could not take control of the drive from Android. Unplug it, plug it back in and try again.")
                conn.close()
                return@runTask
            }
            val d = UsbDrive(conn, bot.iface, bot.bulkIn, bot.bulkOut)
            if (!d.init()) {
                log("The drive did not answer correctly (it may be failing, locked or an unsupported card reader).")
                d.close()
                return@runTask
            }
            drive?.close()
            drive = d
            val info = "Drive: ${d.label.ifEmpty { "USB storage" }} - ${fmtSize(d.sizeBytes)} (${d.blockSize}-byte sectors)"
            setStatus(info)
            log("Connected. $info")
            if (d.blockCount > 0xFFFFFFFFL) log("Note: only the first 2 TB addressable by this app.")
        }
    }

    private fun needDrive(): UsbDrive? {
        val d = drive
        if (d == null) log("No drive connected yet. Tap Connect first.")
        return d
    }

    // ---------- Actions ----------

    private fun diagnose() {
        val d = needDrive() ?: return
        runTask {
            log("--- Diagnose ---")
            Analyzer.analyze(d, ctl)
        }
    }

    private fun recover(resume: Boolean) {
        val d = needDrive() ?: return
        val typed = startPct.text.toString().trim().toDoubleOrNull()
        val prefs = getSharedPreferences("recover", Context.MODE_PRIVATE)
        val savedBlocks = prefs.getLong("blocks", -1L)
        val savedFolder = prefs.getString("folder", null)
        val sameDrive = savedFolder != null && savedBlocks == d.blockCount
        val total = d.blockCount

        var startLba = 0L
        var folder = Carver.newFolderName()
        var serial = 0
        if (resume) {
            val savedLba = prefs.getLong("resume_lba", -1L)
            if (!sameDrive || savedLba <= 0L || savedLba >= total) {
                log("Nothing to resume for this drive. Tap 'Recover files' to start from the beginning, or type a % in the Start at box.")
                return
            }
            startLba = savedLba
            folder = savedFolder!!
            serial = prefs.getInt("serial", 0)
        } else if (typed != null && typed > 0.0) {
            if (typed >= 100.0) {
                log("Start at must be below 100%.")
                return
            }
            startLba = (total * typed / 100.0).toLong()
            if (sameDrive) {
                folder = savedFolder!!
                serial = prefs.getInt("serial", 0)
            }
        }

        runTask {
            log("--- Recover files (read-only) ---")
            val carver = Carver(this, d, ctl, folder, startLba, serial)
            carver.run()
            val e = prefs.edit()
            e.putLong("blocks", d.blockCount)
            e.putString("folder", carver.folder)
            e.putInt("serial", carver.serial)
            e.putLong("resume_lba", if (carver.completed) -1L else carver.resumeLba)
            e.apply()
        }
    }

    private fun repair() {
        val d = needDrive() ?: return
        runTask {
            log("--- Repair: looking for a safe fix ---")
            val plans = Analyzer.analyze(d, ctl)
            runOnUiThread { offerRepairs(d, plans) }
        }
    }

    private fun offerRepairs(d: UsbDrive, plans: List<WritePlan>) {
        if (plans.isEmpty()) return
        val items = plans.map { it.desc }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose a repair")
            .setItems(items) { _, which -> confirm(d, plans[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirm(d: UsbDrive, plan: WritePlan) {
        AlertDialog.Builder(this)
            .setTitle("Write to the drive?")
            .setMessage(
                plan.desc + "\n\nThe original sectors are saved to Downloads/RawRecover first. " +
                    "If the files on this drive matter, run 'Recover files' before repairing.\n\nContinue?"
            )
            .setPositiveButton("Repair") { _, _ -> runTask { doApply(d, plan) } }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doApply(d: UsbDrive, plan: WritePlan) {
        log("--- Applying repair ---")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val ok = Analyzer.apply(d, plan, { lba, data ->
            val out = Saver.open(this, "backup_$stamp", "sector_$lba.bin", "application/octet-stream")
            if (out == null) {
                false
            } else {
                try {
                    out.second.write(data)
                    out.second.close()
                    Saver.finish(this, out.first)
                    true
                } catch (e: IOException) {
                    Saver.discard(this, out.first)
                    false
                }
            }
        }, ctl)
        if (ok) {
            log("Repair written and verified.")
            log("Now unplug the drive and plug it in again. If Android still says it can't read it, open it on a PC (an NTFS volume may not be readable on some phones).")
        } else {
            log("Repair was not completed.")
        }
    }
}
