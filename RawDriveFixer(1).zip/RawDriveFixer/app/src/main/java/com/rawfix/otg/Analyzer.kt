package com.rawfix.otg

import kotlin.math.min

class WritePlan(val desc: String, val writes: List<Pair<Long, ByteArray>>)

class Part(val index: Int, val type: Int, val start: Long, val sectors: Long)

class VolHit(val lba: Long, val kind: String, val sector: ByteArray)

/**
 * Looks at the first sectors of the drive to work out WHY it shows up as RAW, and prepares
 * safe repairs (restoring a backup boot sector, or rebuilding a wiped partition table).
 * Nothing is written here; writes only happen after the user confirms.
 */
object Analyzer {

    fun detect(s: ByteArray, off: Int = 0): String? {
        if (off + 512 > s.size) return null
        if (B.u8(s, off + 510) != 0x55 || B.u8(s, off + 511) != 0xAA) return null
        return when {
            B.ascii(s, off + 3, 8) == "NTFS    " -> "NTFS"
            B.ascii(s, off + 3, 8) == "EXFAT   " -> "exFAT"
            B.ascii(s, off + 82, 5) == "FAT32" -> "FAT32"
            B.ascii(s, off + 54, 5) == "FAT16" -> "FAT16"
            B.ascii(s, off + 54, 5) == "FAT12" -> "FAT12"
            else -> null
        }
    }

    private fun parseMbr(s: ByteArray, diskSectors: Long): List<Part> {
        val out = ArrayList<Part>()
        for (i in 0 until 4) {
            val o = 446 + i * 16
            val type = B.u8(s, o + 4)
            val start = B.le32(s, o + 8)
            val n = B.le32(s, o + 12)
            if (type != 0 && n > 0 && start < diskSectors) out.add(Part(i + 1, type, start, n))
        }
        return out
    }

    private fun parseGpt(d: UsbDrive, ctl: Ctl): List<Part> {
        val out = ArrayList<Part>()
        val h = d.read(1, 1)
        if (h == null || B.ascii(h, 0, 8) != "EFI PART") {
            ctl.log("Protective MBR found but the GPT header is missing or damaged.")
            return out
        }
        val entLba = B.le64(h, 72)
        val n = min(B.le32(h, 80), 128L).toInt()
        val sz = B.le32(h, 84).toInt()
        if (sz < 128 || sz > 512 || n <= 0) return out
        val sectors = (n * sz + 511) / 512
        val e = d.read(entLba, sectors) ?: return out
        for (i in 0 until n) {
            val o = i * sz
            var empty = true
            for (k in 0 until 16) if (e[o + k].toInt() != 0) empty = false
            if (empty) continue
            val first = B.le64(e, o + 32)
            val last = B.le64(e, o + 40)
            if (last >= first && first < d.blockCount) out.add(Part(i + 1, 0xEE, first, last - first + 1))
        }
        return out
    }

    private fun scanVolumes(d: UsbDrive, ctl: Ctl, limitSectors: Long): List<VolHit> {
        val hits = ArrayList<VolHit>()
        val chunk = 128
        var lba = 1L
        val end = min(limitSectors, d.blockCount)
        while (lba < end && !ctl.stopped()) {
            val n = min(chunk.toLong(), end - lba).toInt()
            val buf = d.readLenient(lba, n)
            for (j in 0 until n) {
                val kind = detect(buf, j * 512) ?: continue
                val here = lba + j
                val prev = if (hits.isEmpty()) null else hits[hits.size - 1]
                // skip the backup copies that sit 6 (FAT32) or 12 (exFAT) sectors after the real one
                if (prev != null && prev.kind == kind &&
                    ((kind == "FAT32" && here - prev.lba == 6L) || (kind == "exFAT" && here - prev.lba == 12L))
                ) continue
                hits.add(VolHit(here, kind, buf.copyOfRange(j * 512, j * 512 + 512)))
            }
            lba += n
        }
        return hits
    }

    private fun volumeSectors(h: VolHit, diskSectors: Long): Long {
        val s = h.sector
        var total = when (h.kind) {
            "NTFS" -> B.le64(s, 40) + 1
            "exFAT" -> B.le64(s, 72)
            else -> {
                val t16 = B.le16(s, 19).toLong()
                if (t16 != 0L) t16 else B.le32(s, 32)
            }
        }
        if (total <= 0 || h.lba + total > diskSectors) total = diskSectors - h.lba
        return min(total, 0xFFFFFFFFL)
    }

    private fun buildMbr(old: ByteArray, h: VolHit, diskSectors: Long): ByteArray {
        val m = ByteArray(512)
        val oldOk = B.u8(old, 510) == 0x55 && B.u8(old, 511) == 0xAA
        if (oldOk) {
            System.arraycopy(old, 0, m, 0, 446)
        } else {
            B.put32(m, 440, System.nanoTime() and 0xFFFFFFFFL) // disk signature
        }
        val o = 446
        m[o] = 0
        m[o + 1] = 0xFE.toByte(); m[o + 2] = 0xFF.toByte(); m[o + 3] = 0xFF.toByte()
        val partType: Int = when (h.kind) {
            "FAT32" -> 0x0C
            "FAT16" -> 0x0E
            "FAT12" -> 0x01
            else -> 0x07
        }
        m[o + 4] = partType.toByte()
        m[o + 5] = 0xFE.toByte(); m[o + 6] = 0xFF.toByte(); m[o + 7] = 0xFF.toByte()
        B.put32(m, o + 8, h.lba)
        B.put32(m, o + 12, volumeSectors(h, diskSectors))
        m[510] = 0x55
        m[511] = 0xAA.toByte()
        return m
    }

    private fun tryBackup(d: UsbDrive, p: Part): WritePlan? {
        val fat = d.read(p.start + 6, 1)
        if (fat != null && detect(fat) == "FAT32") {
            return WritePlan(
                "Partition ${p.index}: restore the FAT32 boot sector from its backup copy (sector ${p.start + 6})",
                listOf(Pair(p.start, fat))
            )
        }
        val ex = d.read(p.start + 12, 1)
        if (ex != null && detect(ex) == "exFAT") {
            val region = d.read(p.start + 12, 12)
            if (region != null) {
                return WritePlan(
                    "Partition ${p.index}: restore the exFAT boot region from its backup copy (sector ${p.start + 12})",
                    listOf(Pair(p.start, region))
                )
            }
        }
        val tail = p.start + p.sectors - 1
        if (tail > p.start && tail < d.blockCount) {
            val nt = d.read(tail, 1)
            if (nt != null && detect(nt) == "NTFS") {
                return WritePlan(
                    "Partition ${p.index}: restore the NTFS boot sector from the backup at the end of the partition (sector $tail)",
                    listOf(Pair(p.start, nt))
                )
            }
        }
        return null
    }

    fun analyze(d: UsbDrive, ctl: Ctl): List<WritePlan> {
        val plans = ArrayList<WritePlan>()
        if (d.blockSize != 512) {
            ctl.log("Diagnosis and repair only support 512-byte sectors (this drive reports ${d.blockSize}). File recovery still works.")
            return plans
        }
        ctl.log("Reading the start of the drive...")
        val s0 = d.read(0, 1)
        if (s0 == null) {
            ctl.log("Cannot read sector 0. The drive may be failing or the connection is bad. Try another cable/adapter.")
            return plans
        }
        val fs0 = detect(s0)
        if (fs0 != null) {
            ctl.log("Sector 0 has a valid $fs0 boot sector (no partition table).")
            ctl.log("The boot sector is fine, so the damage is deeper in the file system. Use 'Recover files' to copy your data off, then format the drive.")
            return plans
        }

        val hasSig = B.u8(s0, 510) == 0x55 && B.u8(s0, 511) == 0xAA
        var parts: List<Part> = emptyList()
        if (!hasSig) {
            ctl.log("Sector 0 has no partition-table signature: the partition table looks wiped or overwritten.")
        } else {
            parts = parseMbr(s0, d.blockCount)
            if (parts.any { it.type == 0xEE }) {
                ctl.log("GPT partition table detected.")
                parts = parseGpt(d, ctl)
            }
            if (parts.isEmpty()) ctl.log("Partition table signature present but it lists no usable partitions.")
        }

        var anyHealthy = false
        for (p in parts) {
            val sec = d.read(p.start, 1)
            val fs = if (sec == null) null else detect(sec)
            val where = "Partition ${p.index}: starts at sector ${p.start}, ${fmtSize(p.sectors * 512)}"
            if (fs != null) {
                ctl.log("$where -> $fs boot sector OK")
                anyHealthy = true
            } else {
                ctl.log("$where -> boot sector is damaged or unreadable (this is why it shows as RAW)")
                val plan = tryBackup(d, p)
                if (plan != null) {
                    ctl.log("   A backup boot sector was found.")
                    plans.add(plan)
                } else {
                    ctl.log("   No backup boot sector found at the standard locations.")
                }
            }
        }

        if (!anyHealthy && plans.isEmpty()) {
            ctl.log("Searching the first 32 MB for file-system boot sectors...")
            val hits = scanVolumes(d, ctl, 65536)
            if (hits.isEmpty()) {
                ctl.log("No boot sector found near the start of the drive.")
            } else {
                for (h in hits) {
                    val desc = "Rebuild the partition table so it points to the ${h.kind} volume found at sector ${h.lba}" +
                        " (${fmtSize(volumeSectors(h, d.blockCount) * 512)})"
                    ctl.log("Found a ${h.kind} boot sector at sector ${h.lba}.")
                    plans.add(WritePlan(desc, listOf(Pair(0L, buildMbr(s0, h, d.blockCount)))))
                }
            }
        }

        if (plans.isEmpty()) {
            ctl.log("No automatic repair is possible. Use 'Recover files' to copy what can be found, then format the drive.")
        } else {
            ctl.log("${plans.size} repair option(s) available. Recover your files first if the data matters, then tap 'Repair' and choose one.")
        }
        return plans
    }

    /** Backs up the sectors about to be overwritten, writes the new data and verifies it by reading it back. */
    fun apply(d: UsbDrive, plan: WritePlan, backup: (Long, ByteArray) -> Boolean, ctl: Ctl): Boolean {
        for ((lba, data) in plan.writes) {
            val old = d.read(lba, data.size / 512)
            if (old == null) {
                ctl.log("Could not read sector $lba to back it up. Nothing was changed.")
                return false
            }
            if (!backup(lba, old)) {
                ctl.log("Could not save a backup of sector $lba to Downloads. Nothing was changed.")
                return false
            }
        }
        ctl.log("Backup of the original sectors saved in Downloads/RawRecover.")
        for ((lba, data) in plan.writes) {
            if (!d.write(lba, data)) {
                ctl.log("Write failed at sector $lba. The drive may be write-protected (check the lock switch on SD adapters).")
                return false
            }
            val back = d.read(lba, data.size / 512)
            if (back == null || !back.contentEquals(data)) {
                ctl.log("Verification failed at sector $lba.")
                return false
            }
        }
        return true
    }
}
