package com.rawfix.otg

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.OutputStream

/** Callbacks the long-running jobs use to talk to the UI. */
class Ctl(
    val log: (String) -> Unit,
    val progress: (Int) -> Unit,
    val stopped: () -> Boolean
)

object B {
    fun u8(b: ByteArray, i: Int): Int = b[i].toInt() and 0xFF
    fun le16(b: ByteArray, i: Int): Int = u8(b, i) or (u8(b, i + 1) shl 8)
    fun le32(b: ByteArray, i: Int): Long =
        u8(b, i).toLong() or (u8(b, i + 1).toLong() shl 8) or
            (u8(b, i + 2).toLong() shl 16) or (u8(b, i + 3).toLong() shl 24)

    fun le64(b: ByteArray, i: Int): Long = le32(b, i) or (le32(b, i + 4) shl 32)
    fun be32(b: ByteArray, i: Int): Long =
        (u8(b, i).toLong() shl 24) or (u8(b, i + 1).toLong() shl 16) or
            (u8(b, i + 2).toLong() shl 8) or u8(b, i + 3).toLong()

    fun put32(b: ByteArray, o: Int, v: Long) {
        for (k in 0..3) b[o + k] = (v shr (8 * k)).toByte()
    }

    fun ascii(b: ByteArray, o: Int, n: Int): String = String(b, o, n, Charsets.ISO_8859_1)
}

fun fmtSize(bytes: Long): String {
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var u = 0
    while (v >= 1024.0 && u < units.size - 1) {
        v /= 1024.0
        u++
    }
    return if (u == 0) "$bytes B" else String.format(java.util.Locale.US, "%.1f %s", v, units[u])
}

/** Saves files into Downloads/RawRecover/<folder>/ using MediaStore (no storage permission needed on Android 10+). */
object Saver {
    fun open(ctx: Context, folder: String, name: String, mime: String): Pair<Uri, OutputStream>? {
        val v = ContentValues()
        v.put(MediaStore.Downloads.DISPLAY_NAME, name)
        v.put(MediaStore.Downloads.MIME_TYPE, mime)
        v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/RawRecover/$folder")
        v.put(MediaStore.Downloads.IS_PENDING, 1)
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
        val os = ctx.contentResolver.openOutputStream(uri)
        if (os == null) {
            ctx.contentResolver.delete(uri, null, null)
            return null
        }
        return Pair(uri, os)
    }

    fun finish(ctx: Context, uri: Uri) {
        val v = ContentValues()
        v.put(MediaStore.Downloads.IS_PENDING, 0)
        ctx.contentResolver.update(uri, v, null, null)
    }

    fun discard(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.delete(uri, null, null)
        } catch (_: Exception) {
        }
    }
}
